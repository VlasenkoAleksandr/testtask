package steps.mailbox;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageobjects.mailbox.MailBoxPage;
import steps.MainPageSteps;

public class MailBoxPageSteps extends MainPageSteps {

    private MailBoxPage mailBoxPage;

    public MailBoxPageSteps(WebDriver driver){
        super(driver);
        mailBoxPage = PageFactory.initElements(driver, MailBoxPage.class);
    }

    public void writeAnEmail(){
        WebDriverWait wait = new WebDriverWait(driver,1);
        wait.until(ExpectedConditions.visibilityOf(mailBoxPage.getButtonWriteEmail()));
        mailBoxPage.getButtonWriteEmail().click();
        wait.until(ExpectedConditions.visibilityOf(mailBoxPage.getReceiverEmailAdressTextArea()));
        mailBoxPage.getReceiverEmailAdressTextArea().click();
        mailBoxPage.getReceiverEmailAdress().sendKeys("vlasenkotest@gmail.com");
        mailBoxPage.getEmailTextArea().sendKeys("Hello, world!");
        mailBoxPage.getSendMessage().click();
    }

    public void goToInbox(){
        mailBoxPage.getInBoxButton().click();
    }

    public void openEmail(){
        WebDriverWait wait = new WebDriverWait(driver,10);
        wait.until(ExpectedConditions.visibilityOf(mailBoxPage.getOpenAnEmail()));
        mailBoxPage.getOpenAnEmail().click();
    }

    public boolean verifyTheText(){
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.visibilityOf(mailBoxPage.getEmailText()));
        return mailBoxPage.getEmailText().getText().contains("Hello, world!");
    }
    public void deleteMEssage(){
        mailBoxPage.getdeleteButton().click();
    }

}
