package pageobjects.mailbox;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import pageobjects.MainPage;

public class MailBoxPage extends MainPage{

    @FindBy(xpath = "/html/body/div[7]/div[3]/div/div[2]/div[1]/div[1]/div[1]/div[2]/div/div/div/div[1]/div/div")
    private WebElement buttonWriteEmail;

    public WebElement getButtonWriteEmail() {
        return buttonWriteEmail;
    }

    @FindBy(id=":5w")
    private WebElement receiverEmailAdressTextArea;

    public WebElement getReceiverEmailAdressTextArea() {
        return receiverEmailAdressTextArea;
    }

    @FindBy(id=":8f")
    private WebElement receiverEmailAdress;

    public WebElement getReceiverEmailAdress() {
        return receiverEmailAdress;
    }

    @FindBy(id=":92")
    private WebElement emailTextArea;

    public WebElement getEmailTextArea() {
        return emailTextArea;
    }

    @FindBy(id=":7n")
    private WebElement sendMessage;

    public WebElement getSendMessage() {
        return sendMessage;
    }

    @FindBy(css = ".aio .nU .J-Ke")
    private WebElement inBoxButton;

    public WebElement getInBoxButton() {
        return inBoxButton;
    }

    @FindBy(css = ".xS .xT .y6 .y2")
    private WebElement openAnEmail;

    public WebElement getOpenAnEmail() {
        return openAnEmail;
    }

    @FindBy(css = ".nH .h7 .Bk .G3 div .adn .gs")
    private WebElement emailText;

    public WebElement getEmailText() {
        return emailText;
    }

    @FindBy(css = "#\\3a 5 > div > div.iH.bzn > div > div:nth-child(2) > div.T-I.J-J5-Ji.nX.T-I-ax7.T-I-Js-Gs.ar7 > div > div")
    private WebElement deleteButton;

    public WebElement getdeleteButton() {
        return deleteButton;
    }
}
